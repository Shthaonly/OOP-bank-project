/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banksystem;

/**
 *
 * @author shtha 
 */
public abstract class newAccount {
     
    
     long AccountNum; // Account number
     String Password; // Password
     double balance; // Balance
    
    /**
     * Create an account
     * @param AccountNum 
     * @param Password
     */
    public abstract void createAccount(long AccountNum,String Password);
    
    /**
     * Login function 
     */
    public abstract String enter(Account account[]); 
    
    /**
     * toString method
     * @return Account number and Password and balance
     */
     @Override
    public abstract String toString(); 
    

}
