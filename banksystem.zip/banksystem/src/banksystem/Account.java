
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banksystem;

import java.util.Scanner;

/**
 *
 * @author Shtha
 */
public class Account extends newAccount {

    Scanner sc = new Scanner(System.in);
    protected long AccountNum;
    protected String Password;
    protected double balance;

    public Account() {

    }

    public Account(long AccountNum, String Password) {
        this.AccountNum = AccountNum;
        this.Password = Password;
        this.balance = 0.0;
    }

    public long getAccountNum() {
        return AccountNum;
    }

    public void setAccountNum(long AccountNum) {
        this.AccountNum = AccountNum;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    @Override
    public void createAccount(long AccountNum, String Password) {
        Account newaccount = new Account(AccountNum, Password);
    }

    @Override
    public String enter(Account account[]) {
        String flag = "false";
        System.out.println("please enter your bank Account number");
        long accountNumber = sc.nextLong();
        for (int i = 0; i < account.length; i++) {
            if (account[i].AccountNum != accountNumber) {
                 flag = "true";
                System.out.println("unregistered account, please register first! ");
                System.out.println("----------------------------");
                break;
            } else {
                int adress = i;
                for (int j = 0; j < account.length; j++) {
                    System.out.println("please enter your password");
                    String password = sc.next();
                    if (account[adress].Password.equals(password)) {
                        break;
                    }
                    else{
                       System.out.println("wrong password please try again ");
                       System.out.println("----------------------------");
                    }
                }
                break;
            }
        }
        return flag;
    } 

    @Override
    public boolean equals(Object a) {
        Account acNo = (Account) a;

        return (acNo.AccountNum == this.AccountNum);

    }

    @Override
    public String toString() {
        return "Account{" + ", AccountNum=" + AccountNum + ", Password=" + Password + ", balance=" + balance + '}';
    }
}


